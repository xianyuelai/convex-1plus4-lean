import DominantFiveBody.Main
import Lean

/-! Inspect actual constant types and proof bodies. Imported axiom-summary
metadata is not used by this traversal. This command proves no mathematics. -/
set_option maxHeartbeats 0
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let kernelEnv := env.checked.get
  let mut ownedModules : Array Name := #[]
  for name in env.header.moduleNames do
    if name.toString.startsWith "DominantFiveBody." then
      ownedModules := ownedModules.push name
  let mut seeds : Array Name := #[]
  for (name, _) in kernelEnv.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      if ownedModules.contains env.header.moduleNames[idx]! then
        seeds := seeds.push name
  unless seeds.contains ``DominantFiveBody.main_uniform do
    throwError "Unconditional main_uniform is absent from the project environment"
  let mut todo := seeds
  let mut seen : NameSet := {}
  let mut axioms : NameSet := {}
  let mut edges : Nat := 0
  let mut theoremCount : Nat := 0
  for name in seeds do
    if let some (.thmInfo _) := kernelEnv.find? name then
      theoremCount := theoremCount + 1
  while !todo.isEmpty do
    let name := todo.back!
    todo := todo.pop
    if seen.contains name then continue
    seen := seen.insert name
    let some info := kernelEnv.find? name
      | throwError "Missing reachable kernel declaration: {name}"
    if info.isUnsafe || info.isPartial then
      throwError "Unsafe or partial reachable declaration: {name}"
    if let .axiomInfo _ := info then
      unless [``Classical.choice, ``propext, ``Quot.sound].contains name do
        throwError "Disallowed reachable axiom: {name}"
      axioms := axioms.insert name
    let mut deps := info.type.getUsedConstants
    if let some value := info.value? true then
      deps := deps ++ value.getUsedConstants
    if let .inductInfo ind := info then
      deps := deps ++ ind.ctors.toArray
    edges := edges + deps.size
    todo := todo ++ deps
  let result := Json.mkObj [
    ("passed", toJson true),
    ("method",toJson "Direct traversal of checked declaration types and bodies; no cached axiom summaries"),
    ("modules",toJson (ownedModules.qsort Name.lt |>.map Name.toString)),
    ("project_constants",toJson (seeds.qsort Name.lt |>.map Name.toString)),
    ("project_theorem_count",toJson theoremCount),
    ("reachable_constant_count",toJson seen.size),
    ("dependency_edges",toJson edges),
    ("axioms",toJson (axioms.toArray.qsort Name.lt |>.map Name.toString))]
  liftIO <| IO.FS.writeFile "logs/ENVIRONMENT_AUDIT.json" result.pretty
  logInfo m!"ENVIRONMENT_AUDIT_PASS: {ownedModules.size} modules; {seeds.size} project constants; {theoremCount} project theorems; {seen.size} reachable constants; {edges} edges; axioms {axioms.toArray}"
